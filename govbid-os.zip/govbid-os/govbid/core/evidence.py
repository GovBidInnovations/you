"""
Evidence ledger and enforcement.

This module manages the collection and validation of evidence used to
substantiate claims in the bid proposal.  Each statement in the
interpretation must be backed by verbatim quotations from the solicitation
package with page and section numbers.  Missing evidence should be
explicitly noted as ``NOT FOUND`` or ``NOT PROVIDED`` as dictated by
the Prime Directive.
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class EvidenceItem:
    """Representation of a single piece of evidence supporting a claim."""

    quote: str
    page: Optional[str] = None
    section: Optional[str] = None


class EvidenceLedger:
    """Collection of evidence items associated with an opportunity.

    The ledger enforces that all interpretation statements can be traced back
    to primary source material.  It also records any missing items so that
    decision makers have full visibility into gaps.
    """

    def __init__(self) -> None:
        self._items: List[EvidenceItem] = []
        self._missing: List[str] = []

    def add(self, quote: str, page: Optional[str] = None, section: Optional[str] = None) -> None:
        """Add a new evidence item to the ledger."""
        self._items.append(EvidenceItem(quote=quote, page=page, section=section))

    def record_missing(self, description: str) -> None:
        """Record a description of a missing or unavailable evidence item."""
        self._missing.append(description)

    @property
    def items(self) -> List[EvidenceItem]:
        return list(self._items)

    @property
    def missing_items(self) -> List[str]:
        return list(self._missing)
