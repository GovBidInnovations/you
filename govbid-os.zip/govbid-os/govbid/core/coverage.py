"""
Coverage gating.

This module enforces geographic eligibility rules based on the coverage
bundle.  It uses pre‑defined allowlists of states and counties to determine
whether a solicitation falls within the company's approved service areas.
The coverage bundle should be loaded from the ``schemas`` directory and
cached for repeated use.
"""

from typing import Dict, Set, Tuple


class CoverageBundle:
    """Simple representation of allowed states and counties."""

    def __init__(self, states_by_name: Set[str], counties_by_fips: Set[str]) -> None:
        self.states_by_name = states_by_name
        self.counties_by_fips = counties_by_fips

    def is_allowed_state(self, state: str) -> bool:
        return state in self.states_by_name

    def is_allowed_county(self, fips: str) -> bool:
        return fips in self.counties_by_fips


def load_coverage_bundle(path: str) -> CoverageBundle:
    """Load a coverage bundle from a JSON file.

    The JSON is expected to contain ``states_by_name`` and ``counties_by_fips``
    keys.  Only these keys are used; any other data is ignored.
    """
    import json
    with open(path, 'r', encoding='utf-8') as fp:
        data = json.load(fp)
    states = set(data.get('states_by_name', []))
    counties = set(data.get('counties_by_fips', []))
    return CoverageBundle(states_by_name=states, counties_by_fips=counties)
