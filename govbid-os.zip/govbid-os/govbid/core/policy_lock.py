"""
Core constants and configuration for the GovBid operating system.

This module defines the "locked" policy values that codify the Prime
Directive and the financial guardrails.  These values should never be
modified at runtime; they are intended to be read by the gate and margin
controllers to enforce minimum margins, overhead percentages and risk
thresholds.

Attributes
----------
MIN_GM_BASELINE : float
    The baseline minimum gross margin (GM) percentage required on all
    opportunities before any adjustments (e.g., NM uplift) are applied.
OVERHEAD_PERCENT : float
    The overhead percentage applied to all cost of goods sold to account for
    operational expenses.
NM_TARGET : float
    The target net margin (NM) percentage for the business.
NM_FLOOR : float
    The minimum acceptable net margin; crossing this threshold triggers
    freeze controls.
FREEZE_THRESHOLD : float
    Bid value threshold (in dollars) below which bids are automatically
    frozen when in NM distress.
"""

from dataclasses import dataclass

@dataclass(frozen=True)
class PolicyLock:
    """Container for immutable policy constants.

    Instances of this dataclass should be imported by other modules rather
    than re‑defining constants manually.  See the Prime Directive document
    for the rationale behind each value.
    """

    min_gm_baseline: float = 0.25  # 25% minimum gross margin
    overhead_percent: float = 0.14  # 14% overhead on cost of goods sold
    nm_target: float = 0.10  # 10% target net margin
    nm_floor: float = 0.08  # 8% net margin floor
    freeze_threshold: float = 25_000.0  # freeze bids under $25k when NM distressed


POLICY = PolicyLock()
