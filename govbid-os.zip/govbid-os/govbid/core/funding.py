"""
Funding model utilities.

This module implements simple models for estimating the peak exposure of a
bid and comparing it against available funding capacity.  It is also
responsible for enforcing the "unbounded call order" rule when multiple
funding sources exist, as described in the Prime Directive.
"""

from dataclasses import dataclass


@dataclass
class FundingContext:
    """Inputs required to evaluate funding viability."""

    bid_value: float
    funding_capacity: float


def compute_peak_exposure(bid_value: float) -> float:
    """Estimate the peak exposure for a bid.

    This simplistic implementation treats the bid value as the peak exposure.
    More sophisticated models may factor in payment schedules and revenue
    recognition profiles.
    """
    return bid_value


def has_sufficient_funding(ctx: FundingContext) -> bool:
    """Return True if the available funding capacity covers the estimated exposure."""
    return compute_peak_exposure(ctx.bid_value) <= ctx.funding_capacity
