"""
Receivables financing checks.

This module implements validations and uplift calculations when a bid is
proposed to be financed through receivables.  It enforces the RF‑1
through RF‑4 rules and ensures written confirmation of financing is
available before any uplift is applied.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ReceivablesContext:
    """Inputs required to evaluate receivables financing."""

    using_financing: bool
    written_confirmation: Optional[str] = None
    per_unit_uplift: float = 0.0  # Uplift per unit of revenue when financing is used


def validate_financing(ctx: ReceivablesContext) -> bool:
    """Validate that all receivables financing conditions are met."""
    if not ctx.using_financing:
        return True
    return bool(ctx.written_confirmation)


def compute_financing_uplift(ctx: ReceivablesContext) -> float:
    """Compute the revenue uplift when receivables financing is used.

    Requires that written confirmation is provided.  Returns zero if
    financing is not used or confirmation is missing.
    """
    if not validate_financing(ctx):
        return 0.0
    return ctx.per_unit_uplift
