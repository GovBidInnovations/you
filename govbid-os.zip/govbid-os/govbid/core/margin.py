"""
Margin control utilities.

This module computes minimum gross margin requirements based on the
organization's trailing net margin performance, cash reserves and DSO
realizations.  It also determines whether freeze mode should be triggered
when the NM floor is breached.
"""

from dataclasses import dataclass

from .policy_lock import POLICY


@dataclass
class MarginContext:
    """Inputs required to calculate margin thresholds."""

    trailing_nm: float
    dso_real: float
    cash_reserve_months: float


def compute_min_gm(ctx: MarginContext) -> float:
    """Compute the minimum gross margin required under current conditions.

    Adds uplift when DSO or cash reserve thresholds are breached.
    """
    min_gm = POLICY.min_gm_baseline
    # Example uplifts: +2% if DSO exceeds 60 days or cash reserves < 3 months
    if ctx.dso_real > 60:
        min_gm += 0.02
    if ctx.cash_reserve_months < 3:
        min_gm += 0.02
    return min_gm


def is_freeze_mode(ctx: MarginContext) -> bool:
    """Return True if the NM floor has been breached and freeze controls apply."""
    return ctx.trailing_nm < POLICY.nm_floor
