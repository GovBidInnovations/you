"""
Goods‑only validator.

This module provides helpers to detect service creep in opportunity
descriptions and automatically produce ``FAIL`` decisions for bids that
include non‑goods components.  The Prime Directive mandates a strict
goods‑only posture; installation, staffing, maintenance labour, managed
services and other service elements are prohibited.
"""

import re
from typing import List


PROHIBITED_KEYWORDS: List[str] = [
    "installation",
    "staffing",
    "maintenance",
    "managed services",
    "turnkey",
]


def contains_service_creep(text: str) -> bool:
    """Return True if the provided text appears to include prohibited services.

    Parameters
    ----------
    text : str
        Combined solicitation description and line items from the dossier.

    Returns
    -------
    bool
        True if any prohibited keyword is present; otherwise False.

    Note
    ----
    This is a simple keyword matcher.  Future versions could employ
    NLP techniques or pattern matching on structured line items to
    improve accuracy.
    """

    lower = text.lower()
    for kw in PROHIBITED_KEYWORDS:
        if re.search(r"\b" + re.escape(kw) + r"\b", lower):
            return True
    return False
