"""
Top‑level decision engine.

This module coordinates the execution of gates, margin controls, funding
checks and receivables validation to arrive at a final bid decision.  It
produces a structured result with the sections mandated by the Prime
Directive.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .gates import GateResult, run_gates
from .margin import MarginContext, compute_min_gm, is_freeze_mode
from .funding import FundingContext, has_sufficient_funding
from .receivables import ReceivablesContext, validate_financing, compute_financing_uplift


@dataclass
class Decision:
    """Structured bid decision output."""

    decision: str
    hard_stops: List[str]
    gate_results: Dict[str, GateResult]
    quoted_language: List[str]
    interpretation: List[str]
    pricing_summary: str
    funding_summary: str
    risks: List[str]
    missing_items: List[str]


def make_decision(dossier: "Dossier", runtime_config: dict) -> Decision:  # noqa: F821
    """Produce a bid decision for the given dossier.

    Parameters
    ----------
    dossier : Dossier
        Structured bid opportunity.  See ``govbid.models.dossier`` for the
        expected fields.
    runtime_config : dict
        Runtime financial inputs including trailing NM, DSO, cash reserves
        and funding capacity.  See ``config/runtime.yaml`` for examples.

    Returns
    -------
    Decision
        A structured decision containing all mandatory sections.

    Note
    ----
    This stub does not implement the full decision logic.  It illustrates
    how to pull together the various controllers and assemble the result.
    """
    # Execute gates
    gates = run_gates(dossier)

    hard_stops: List[str] = []

    # Evaluate margins
    margin_ctx = MarginContext(
        trailing_nm=runtime_config.get('nm_trailing_90_day', 0.0),
        dso_real=runtime_config.get('dso_real', 0.0),
        cash_reserve_months=runtime_config.get('cash_reserve_months', 0.0),
    )
    min_gm_required = compute_min_gm(margin_ctx)
    freeze = is_freeze_mode(margin_ctx)

    # Evaluate funding
    funding_ctx = FundingContext(
        bid_value=dossier.bid_value if hasattr(dossier, 'bid_value') else 0.0,
        funding_capacity=runtime_config.get('funding_capacity', 0.0),
    )
    funding_ok = has_sufficient_funding(funding_ctx)

    # Evaluate receivables financing
    receivables_ctx = ReceivablesContext(
        using_financing=runtime_config.get('using_financing', False),
        written_confirmation=runtime_config.get('financing_confirmation'),
        per_unit_uplift=runtime_config.get('financing_uplift', 0.0),
    )
    financing_ok = validate_financing(receivables_ctx)
    financing_uplift = compute_financing_uplift(receivables_ctx)

    # Determine final decision (stub logic)
    decision = "BID"
    if freeze:
        decision = "NO-BID"
        hard_stops.append("Net margin floor breached; freeze mode active")
    elif not funding_ok:
        decision = "NO-BID"
        hard_stops.append("Insufficient funding capacity")
    elif not financing_ok:
        decision = "NO-BID"
        hard_stops.append("Receivables financing conditions not met")

    pricing_summary = f"Minimum GM required: {min_gm_required:.2%}"  # stub
    funding_summary = f"Funding capacity sufficient: {funding_ok}"  # stub

    return Decision(
        decision=decision,
        hard_stops=hard_stops,
        gate_results=gates,
        quoted_language=[],
        interpretation=[],
        pricing_summary=pricing_summary,
        funding_summary=funding_summary,
        risks=[],
        missing_items=[],
    )
