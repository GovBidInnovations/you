"""
Data model for opportunity dossiers.

A ``Dossier`` encapsulates all structured information about a bid
opportunity, including customer details, solicitation requirements, line
items and financial parameters.  The model defined here uses pydantic
dataclasses for runtime type checking and validation.
"""

from dataclasses import dataclass, field
from typing import List, Optional

from pydantic.dataclasses import dataclass as pydantic_dataclass


@pydantic_dataclass
class LineItem:
    """Representation of an individual line item in the bid."""

    description: str
    quantity: float
    unit_price: float


@pydantic_dataclass
class Dossier:
    """High‑level representation of a bid opportunity.

    This model is intentionally minimal.  Real dossiers may include many
    additional fields such as solicitation identifiers, customer
    demographics, performance requirements and attachments.  Extend
    this class as needed to match the versioned dossier template.
    """

    id: str
    title: str
    description: Optional[str] = None
    bid_value: Optional[float] = None
    line_items: List[LineItem] = field(default_factory=list)
