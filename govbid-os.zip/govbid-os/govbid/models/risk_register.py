"""
Risk register model.

The risk register collects all identified risks associated with a bid,
including compliance issues, financial exposures, scheduling conflicts
and operational concerns.  Each risk is represented by a short
description and an optional severity level.
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Risk:
    description: str
    severity: Optional[str] = None  # e.g. "low", "medium", "high"


@dataclass
class RiskRegister:
    """Collection of risks for a bid."""

    risks: List[Risk]

    def add(self, description: str, severity: Optional[str] = None) -> None:
        self.risks.append(Risk(description=description, severity=severity))