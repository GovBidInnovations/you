"""
Data structures for funding analysis.

This module defines container classes that capture the output of the
funding analysis process.  Separating the data representation from the
logic (implemented in :mod:`govbid.core.funding`) facilitates testing and
report generation.
"""

from dataclasses import dataclass


@dataclass
class FundingAnalysis:
    peak_exposure: float
    funding_capacity: float
    sufficient: bool
