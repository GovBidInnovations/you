"""
Data model wrapper around the evidence ledger.

This module re‑exports the :class:`EvidenceLedger` type from
``govbid.core.evidence`` for convenience.  It allows the ledger to be used
as part of higher‑level data models without importing from the core
package.
"""

from govbid.core.evidence import EvidenceLedger, EvidenceItem  # noqa: F401

__all__ = ["EvidenceLedger", "EvidenceItem"]