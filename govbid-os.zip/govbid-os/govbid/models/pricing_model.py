"""
Pricing model utilities.

This module provides helpers for computing gross margin and other pricing
metrics based on line items.  It is separate from the margin control
logic in :mod:`govbid.core.margin` to allow reuse in reporting and
analysis.
"""

from typing import Iterable

from .dossier import LineItem


def compute_total_revenue(items: Iterable[LineItem]) -> float:
    """Return the total revenue of all line items."""
    return sum(item.quantity * item.unit_price for item in items)


def compute_gross_margin(revenue: float, cost_of_goods_sold: float) -> float:
    """Return the gross margin percentage.

    Parameters
    ----------
    revenue : float
        Total revenue.
    cost_of_goods_sold : float
        Total cost of goods sold.

    Returns
    -------
    float
        Gross margin expressed as a fraction of revenue (0–1).  Returns
        zero when revenue is zero to avoid division by zero.
    """
    if revenue == 0:
        return 0.0
    return (revenue - cost_of_goods_sold) / revenue
