"""
Output writer utilities.

This module contains helper functions to persist the results of a bid
evaluation.  It can serialize :class:`govbid.core.decision.Decision`
instances to JSON or write human‑readable Markdown summaries.
"""

import json
from pathlib import Path
from typing import Any

from ..core.decision import Decision


def save_decision_json(decision: Decision, path: str | Path) -> None:
    """Serialize a decision to JSON.

    Parameters
    ----------
    decision : Decision
        The decision object to serialize.  Dataclasses are converted
        recursively to dictionaries.
    path : str or Path
        Destination file path.  Parent directories will be created if
        necessary.
    """
    obj = _decision_to_dict(decision)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as fp:
        json.dump(obj, fp, indent=2)


def _decision_to_dict(decision: Decision) -> Any:
    """Convert a Decision dataclass to a dictionary."""
    from dataclasses import asdict
    return asdict(decision)
