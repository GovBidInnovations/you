"""
PDF extraction utility.

This optional module provides a helper to extract text and page mappings
from PDF documents.  It can be used to create the evidence ledger from
solicitation packages.  Implementation is left to the integrator; see
libraries such as ``pdfminer`` or ``PyPDF2``.
"""

def extract_text_from_pdf(path: str) -> str:
    """Extract all text from the given PDF file.

    This stub simply raises ``NotImplementedError``.  Integrators should
    plug in a PDF parsing library here.
    """
    raise NotImplementedError("PDF extraction is not yet implemented")
