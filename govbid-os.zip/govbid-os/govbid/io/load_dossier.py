"""
Dossier loader.

This module contains utility functions to load a dossier from a JSON file
and validate it against the versioned schema.  For now it simply
deserializes JSON into the :class:`govbid.models.dossier.Dossier` model.
Future versions should integrate JSON schema validation using the
template in the ``schemas`` directory.
"""

import json
from pathlib import Path
from typing import Any

from ..models.dossier import Dossier


def load_dossier(path: str | Path) -> Dossier:
    """Load a dossier from a JSON file.

    Parameters
    ----------
    path : str or Path
        Path to the dossier JSON file.

    Returns
    -------
    Dossier
        A populated dossier dataclass.
    """
    with open(path, 'r', encoding='utf-8') as fp:
        data: Any = json.load(fp)
    # Pydantic will perform runtime validation
    return Dossier(**data)
