"""
The :mod:`govbid` package exposes the public API of the GovBid operating
system.  Consumers should import high‑level functions from the subpackages
instead of accessing module internals directly.  See the documentation and
source code under :mod:`govbid.core` and :mod:`govbid.cli` for details.
"""

# Re‑export key entrypoints for convenience.  These should be defined in the
# respective submodules once the implementation is complete.
from .core.decision import make_decision  # noqa: F401
from .cli.main import main  # noqa: F401

__all__ = [
    "make_decision",
    "main",
]