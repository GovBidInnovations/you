"""
CLI command definitions.

This module defines named functions corresponding to CLI commands.  The
``main`` function in :mod:`govbid.cli.main` binds these commands to
subcommands.  Splitting commands into a separate module aids testability
and reuse.
"""

from pathlib import Path
from typing import Dict, Any

from ..io.load_dossier import load_dossier
from ..core.decision import make_decision


def review_command(dossier_path: Path, runtime_config: Dict[str, Any] | None = None) -> None:
    """Evaluate a dossier and print the decision as Markdown."""
    dossier = load_dossier(dossier_path)
    decision = make_decision(dossier, runtime_config or {})
    from ..output.formatter import format_decision_markdown

    md = format_decision_markdown(decision)
    print(md)
