"""
Command‑line interface for GovBid OS.

This module defines an entrypoint callable ``main`` that can be
registered via the project's console scripts.  It uses argparse to
provide a ``review`` subcommand that evaluates a dossier and prints the
decision.
"""

import argparse
from pathlib import Path

from ..io.load_dossier import load_dossier
from ..core.decision import make_decision
from ..output.formatter import format_decision_markdown


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="govbid")
    subparsers = parser.add_subparsers(dest="command", required=True)
    review_parser = subparsers.add_parser("review", help="Review a dossier and output a decision")
    review_parser.add_argument("dossier", type=Path, help="Path to the dossier JSON file")
    review_parser.add_argument("--runtime-config", type=Path, dest="runtime_config", help="Path to runtime YAML configuration")

    args = parser.parse_args(argv)
    if args.command == "review":
        # Load dossier
        dossier = load_dossier(args.dossier)
        # Load runtime config (optional)
        runtime: dict = {}
        if args.runtime_config:
            import yaml  # type: ignore
            with open(args.runtime_config, 'r', encoding='utf-8') as f:
                runtime = yaml.safe_load(f) or {}
        decision = make_decision(dossier, runtime)
        md = format_decision_markdown(decision)
        print(md)
