"""
Decision formatter.

This module assembles the mandatory bid decision sections into a
human‑readable Markdown string.  The format is dictated by the Prime
Directive and should include the following headers in order:

* BID DECISION
* HARD STOPS
* GUBES GATES
* QUOTED LANGUAGE
* INTERPRETATION
* PRICING SUMMARY
* FUNDING SUMMARY
* RISKS
* MISSING ITEMS
"""

from typing import List

from ..core.decision import Decision


def format_decision_markdown(decision: Decision) -> str:
    """Return a Markdown rendering of the decision object."""
    lines: List[str] = []
    lines.append("## BID DECISION\n")
    lines.append(decision.decision + "\n")
    lines.append("## HARD STOPS\n")
    lines.extend((stop + "\n") for stop in (decision.hard_stops or ["None"]))
    lines.append("## GUBES GATES\n")
    for gate, result in decision.gate_results.items():
        lines.append(f"* {gate}: {result.status.name}\n")
        if result.reason:
            lines.append(f"  - {result.reason}\n")
    lines.append("## QUOTED LANGUAGE\n")
    lines.extend((ql + "\n") for ql in (decision.quoted_language or ["None"]))
    lines.append("## INTERPRETATION\n")
    lines.extend((interp + "\n") for interp in (decision.interpretation or ["None"]))
    lines.append("## PRICING SUMMARY\n")
    lines.append(decision.pricing_summary + "\n")
    lines.append("## FUNDING SUMMARY\n")
    lines.append(decision.funding_summary + "\n")
    lines.append("## RISKS\n")
    lines.extend((risk + "\n") for risk in (decision.risks or ["None"]))
    lines.append("## MISSING ITEMS\n")
    lines.extend((miss + "\n") for miss in (decision.missing_items or ["None"]))
    return "".join(lines)
