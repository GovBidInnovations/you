"""
Audit logger.

This module provides a basic in‑memory audit log for capturing inputs,
intermediate computations and outputs when evaluating bids.  A more
sophisticated implementation might write to persistent storage or hook
into the organisation's logging infrastructure.
"""

from typing import Any, Dict, List


class AuditLogger:
    """Simple audit logger."""

    def __init__(self) -> None:
        self.entries: List[Dict[str, Any]] = []

    def log(self, message: str, **kwargs: Any) -> None:
        """Record a message and associated context."""
        entry = {"message": message, **kwargs}
        self.entries.append(entry)

    def to_dict(self) -> List[Dict[str, Any]]:
        return list(self.entries)
