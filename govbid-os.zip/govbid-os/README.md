# GovBid OS

This repository contains the policy‑locked execution engine for GovBid.  The
engine enforces the Prime Directive and processes structured dossiers to
determine bid outcomes.  It is structured as a Python package with clear
separation between the core policy logic, data models, input/output helpers,
formatting code, and a command‑line interface.  See the docstrings in the
`govbid/core` modules for high‑level descriptions of the logic encoded by
each component.
