from govbid.core.receivables import ReceivablesContext, validate_financing, compute_financing_uplift


def test_validate_financing():
    ctx = ReceivablesContext(using_financing=False)
    assert validate_financing(ctx) is True
    ctx = ReceivablesContext(using_financing=True, written_confirmation="yes")
    assert validate_financing(ctx) is True
    ctx = ReceivablesContext(using_financing=True, written_confirmation=None)
    assert validate_financing(ctx) is False


def test_compute_financing_uplift():
    ctx = ReceivablesContext(using_financing=True, written_confirmation="yes", per_unit_uplift=0.05)
    assert compute_financing_uplift(ctx) == 0.05
    ctx = ReceivablesContext(using_financing=True, written_confirmation=None, per_unit_uplift=0.05)
    assert compute_financing_uplift(ctx) == 0.0