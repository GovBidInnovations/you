"""Pytest configuration to ensure the package can be imported without installation."""

import sys
from pathlib import Path

# Add the parent directory (project root) to sys.path so that 'govbid'
# can be imported when running tests without installing the package.
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))