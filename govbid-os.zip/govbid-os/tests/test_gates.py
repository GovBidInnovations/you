import pytest

from govbid.core.gates import run_gates
from govbid.models.dossier import Dossier


def test_run_gates_returns_dict():
    dossier = Dossier(id="123", title="Test Bid")
    result = run_gates(dossier)
    assert isinstance(result, dict)