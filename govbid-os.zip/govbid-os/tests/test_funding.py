from govbid.core.funding import FundingContext, compute_peak_exposure, has_sufficient_funding


def test_compute_peak_exposure():
    assert compute_peak_exposure(100000) == 100000


def test_has_sufficient_funding():
    ctx = FundingContext(bid_value=50000, funding_capacity=100000)
    assert has_sufficient_funding(ctx) is True
    ctx = FundingContext(bid_value=150000, funding_capacity=100000)
    assert has_sufficient_funding(ctx) is False