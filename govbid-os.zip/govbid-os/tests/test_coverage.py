from govbid.core.coverage import CoverageBundle


def test_coverage_bundle():
    bundle = CoverageBundle(states_by_name={"NY", "CA"}, counties_by_fips={"36061", "06075"})
    assert bundle.is_allowed_state("NY") is True
    assert bundle.is_allowed_state("TX") is False
    assert bundle.is_allowed_county("36061") is True
    assert bundle.is_allowed_county("99999") is False