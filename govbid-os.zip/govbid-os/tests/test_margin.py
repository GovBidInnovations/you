import pytest

from govbid.core.margin import MarginContext, compute_min_gm, is_freeze_mode


def test_compute_min_gm_base():
    ctx = MarginContext(trailing_nm=0.12, dso_real=30, cash_reserve_months=4)
    # Should equal baseline (0.25) with no uplift
    assert compute_min_gm(ctx) == 0.25


def test_compute_min_gm_with_uplift():
    ctx = MarginContext(trailing_nm=0.12, dso_real=70, cash_reserve_months=2)
    # Two uplifts of 0.02 each -> 0.25 + 0.04 = 0.29
    # Use approx to account for floating‑point precision
    assert compute_min_gm(ctx) == pytest.approx(0.29)


def test_is_freeze_mode():
    ctx = MarginContext(trailing_nm=0.05, dso_real=30, cash_reserve_months=4)
    assert is_freeze_mode(ctx) is True