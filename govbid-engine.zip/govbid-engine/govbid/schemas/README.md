# GovBid Engine Schemas

This directory is intentionally empty. At runtime, the engine expects to find
the authoritative dossier template and coverage bundle JSON files here:

- `GovBid_DOSSIER_Template_v2.1.0.json`
- `GovBid_Coverage_Bundle_v2.0.0.json`

These files are not included in the repository to avoid duplicating large
binaries. To run the engine, copy the official schema files into this
directory. See the project `README.md` for details.